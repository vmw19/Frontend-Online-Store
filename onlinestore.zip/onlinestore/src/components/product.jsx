import "./product.css";
import QuantityPicker from "./quantityPicker";

const Product = () => {
return (
    <div className="product">

<img src="/images/blackheels.jpg"></img>

    <h3> Black Heels</h3>

    <label>15.00</label>
    <label>18.00</label>

        <QuantityPicker></QuantityPicker>

        <button className="btn btn-sm btn-primary">Add to Cart</button>

    </div>
);
}

export default Product;
